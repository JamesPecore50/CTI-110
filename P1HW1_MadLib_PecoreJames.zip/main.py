first_name = str(input())
generic_location = str(input())
whole_number = str(input())
plural_noun = str(input())



print(first_name, 'went to', generic_location, 'to buy', whole_number, 'different types of', plural_noun)